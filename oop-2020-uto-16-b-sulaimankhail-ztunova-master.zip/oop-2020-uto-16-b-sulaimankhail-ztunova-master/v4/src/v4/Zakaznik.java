package v4;

public class Zakaznik {
	String meno;
	int vek;
	int id;
	Ucet ucet;
	
	public Zakaznik() {
		meno= " ";
		id= 0;
	}
		
	Zakaznik(String nMeno, Ucet nUcet, int nId, int nVek)
	{
		this.meno= nMeno;
		this.ucet= nUcet;
		this.id= nId;
		this.vek= nVek;
	}
		
	public void zobraz()
	{
		System.out.println("Meno zakaznika: "+ meno + " vek: "+ vek+" ID: "+id+ ",cislo uctu: "+ ucet.getCisloUctu() + ", zostatok na ucte: "+ ucet.getZostatok());
	}
		
	public String getMeno()
	{
		return meno;
	}
	
	public void setMeno(String nMeno) {
		this.meno= nMeno;
	}
		
	public Ucet getUcet()
	{
		return ucet;
	}
	
	public int getId() {
		return id;
	}
	
	public int getVek() {
		return vek;
	}

	
}
