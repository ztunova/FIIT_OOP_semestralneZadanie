package v4;

public class Zaznam {
	private String poznamka;
	private double zostavajucaSuma;
	private double zmena;
	private String typ;
	
	public Zaznam() {
		typ= " ";
		poznamka= " ";
		zostavajucaSuma= 0.0;
		zmena= 0.0;
	}
	
	public void pridajZaznam(String nTyp, String nPoznamka, double nZmena, double nZostatok){
		typ= nTyp;
		poznamka= nPoznamka;
		zmena= nZmena;
		zostavajucaSuma= nZostatok;
	}
	
	public void vypisZaznam() {
		System.out.println("Typ zaznamu: "+ typ);
		if(poznamka == null) {
			System.out.println("Poznamka: ----");
		} else {
			System.out.println("Poznamka: "+ poznamka);
		}
		System.out.printf("Suma v pohybe: %.2f\n", zmena);
		System.out.printf("Zostavajuca suma: %.2f\n", zostavajucaSuma);
		//System.out.println("---------------------");
	}
}
