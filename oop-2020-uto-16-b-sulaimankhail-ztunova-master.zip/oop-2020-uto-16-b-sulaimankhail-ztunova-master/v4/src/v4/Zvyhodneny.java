package v4;

public class Zvyhodneny extends Zakaznik {
	String typ;
	
	Zvyhodneny(String nMeno, Ucet nUcet, int nId, int nVek, String nTyp)
	{
		this.meno= nMeno;
		this.ucet= nUcet;
		this.id= nId;
		this.vek= nVek;
		this.typ= nTyp;
	}
	
	public String getTyp() {
		return typ;
	}
	
	public void setTyp(String nTyp) {
		this.typ= nTyp;
	}
	
	public void zobraz()
	{
		System.out.println("Meno zakaznika: "+ meno + " vek: "+ vek+ " status: "+ typ+" ID: "+id+ ",cislo uctu: "+ ucet.getCisloUctu() + ", zostatok na ucte: "+ ucet.getZostatok());
	}
}
