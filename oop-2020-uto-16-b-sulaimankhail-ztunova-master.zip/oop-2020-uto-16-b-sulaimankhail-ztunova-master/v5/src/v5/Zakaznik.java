package v5;

public class Zakaznik {
	protected String meno;
	protected int vek;
	protected int id;
	protected Ucet ucet;
	protected boolean vytvoreneSporenie= false;
	protected SporiaciUcet sporiaciUcet;
	
	public Zakaznik() {
		meno= " ";
		id= 0;
	}
		
	public Zakaznik(String nMeno, Ucet nUcet, int nId, int nVek)
	{
		this.meno= nMeno;
		this.ucet= nUcet;
		//this.sporiaciUcet= nSporiaci;
		this.id= nId;
		this.vek= nVek;
	}
		
	public void zobraz()
	{
		System.out.println("Meno zakaznika: "+ meno + " vek: "+ vek+" ID: "+id+ ",cislo uctu: "+ ucet.getCisloUctu() + ", zostatok na ucte: "+ ucet.getZostatok());
	}
		
	public String getMeno()
	{
		return meno;
	}
	
	public void setMeno(String nMeno) {
		this.meno= nMeno;
	}
		
	public Ucet getUcet()
	{
		return ucet;
	}
	
	public boolean getVytvoreneSporenie() {
		return vytvoreneSporenie;
	}
	
	public void setVytvoreneSporenie(boolean stav) {
		this.vytvoreneSporenie= stav;
	}
	
	public void setSporenie(SporiaciUcet nSporenie) {
		this.sporiaciUcet = nSporenie;
	}
	
	public SporiaciUcet getSporiaciUcet()
	{
		return sporiaciUcet;
	}
	
	public int getId() {
		return id;
	}
	
	public int getVek() {
		return vek;
	}

	
}
