package v5;

public class NedostatocnyZostatokException extends Exception{
	
	public NedostatocnyZostatokException()
    {
        super();
    }
    public NedostatocnyZostatokException(double kolko)
    {
        super("Nedostatocny zostatok na ucte: " + kolko);
    }
    
}
