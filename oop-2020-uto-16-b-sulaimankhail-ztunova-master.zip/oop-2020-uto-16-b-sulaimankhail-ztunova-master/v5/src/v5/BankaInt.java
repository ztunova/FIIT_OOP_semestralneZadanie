package v5;

import java.util.ArrayList;

public interface BankaInt {
	void vypocitajUrok(Zakaznik zakaznik);
	Zakaznik najdiZakaznika(int hladaneId);
	void novyZakaznik(String nMeno, Ucet nUcet, int nId, int nVek);
	void novyZvyhodneny(String nMeno, Ucet nUcet, int nId, int nVek, String nTyp);
	ArrayList<Zakaznik> getZakaznici();
	int getPocetZakaznikov();
	double getUrokovaMiera();
	double getPoplatok();
	 

}
