package v5;

import java.util.ArrayList;

public class SporiaciUcet {
	protected double zostatok;
	protected String cisloUctu;
	//private boolean prvaPlatba= true;
	private int pocitadlo;
	protected ArrayList <Zaznam> platby;
	
	
	public SporiaciUcet() {
		cisloUctu= " ";
		zostatok= 0.0;
		pocitadlo= 0;
		initZaznamy();
	}
	
	public SporiaciUcet(String nCisloUctu, double nZostatok) {
		cisloUctu= nCisloUctu;
		zostatok= nZostatok;
		pocitadlo=0;
		initZaznamy();
	}
	
	private void initZaznamy() {
		platby= new ArrayList<Zaznam>();
		platby.add(new Zaznam());
		platby.get(pocitadlo).pridajZaznam("Pociatocny vklad", "Zalozenie uctu", zostatok, zostatok);
		pocitadlo= pocitadlo+1;
	}
	
	public void vklad(double kolko)
	{
		if(kolko>= 0) {
			zostatok= zostatok + kolko;
			platby.add(new Zaznam());
			Zaznam pridany= platby.get(pocitadlo);
			pridany.pridajZaznam("Vklad", null, kolko, zostatok);
			pocitadlo= pocitadlo+1;
			System.out.println(kolko+" bolo uspesne vlozene na ucet. " + "Novy zostatok je "+zostatok);
		}
		else {
			System.out.println("Vloz kladnu sumu");
		}
		
	}
	
	/*public void skontroluj(double suma) throws NedostatocnyZostatokException
	{
		if(suma < 50) {
			throw new NedostatocnyZostatokException(suma);
		}
	}*/
	
	/*public void platba(double kolko, String poznm, double poplatok) 
	{
		if (kolko >= 0) {
			if(prvaPlatba== true)
			{
				double pomocny= zostatok;
				pomocny= pomocny - kolko;
				
				try
				{
					skontroluj(pomocny);
					zostatok = zostatok - kolko;
					platby.add(new Zaznam());
					Zaznam pridany= platby.get(pocitadlo);
					pridany.pridajZaznam("Platba", poznm, kolko, zostatok);
					pocitadlo= pocitadlo +1;
					System.out.println("Prva platba uspesna, zvysny zostatok: "+ zostatok);
					prvaPlatba= false;
				}
				catch (NedostatocnyZostatokException ex)
				{
					ex.printStackTrace();
				}
				
			}
			else {
				Banka banka= new Banka();
				double pomocny= zostatok;
				pomocny= pomocny - kolko - poplatok;
				
				try
				{
					skontroluj(pomocny);
					zostatok = zostatok - kolko - poplatok;
					platby.add(new Zaznam());
					Zaznam pridany= platby.get(pocitadlo);
					pridany.pridajZaznam("Platba", poznm, kolko, zostatok);
					pocitadlo= pocitadlo +1;
					System.out.println("Platba uspesna, stiahnuty poplatok: " +banka.getPoplatok()+" zvysny zostatok: "+ zostatok);
				}
				catch (NedostatocnyZostatokException ex)
				{
					ex.printStackTrace();
				}
				
			}
		}
		else {
			System.out.println("Plat kladnu sumu");
		}
	}*/
	
	public void vypisPlatby() {
		for(Zaznam zaznam : platby) {
			if (zaznam.getZmena() != 0.0) {
				System.out.println("*************************");
				//System.out.println("Nazov uctu: "+ getMeno());
				System.out.println("Cislo uctu: "+ getCisloUctu());
				zaznam.vypisZaznam();
				System.out.println("*************************");
			}
		}
	}
	
	public String getCisloUctu() {
		return cisloUctu;
	}
	
	public void setCisloUctu(String cislo) {
		this.cisloUctu= cislo;
	}
	
	public double getZostatok() {
		return zostatok;
	}
	
	public void setZostatok(double suma) {
		this.zostatok= suma;
	}
	
	public int getPocitadlo()
	{
		return pocitadlo;
	}

}
