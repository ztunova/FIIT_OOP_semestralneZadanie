package v5;

import java.util.ArrayList;

public class Banka implements BankaInt {
	private double urokovaMiera= 8.5;
	private double poplatok= 10;
	private ArrayList <Zakaznik> zakaznici;
	private int pocetZakaznikov;
	
	public void vypocitajUrok(Zakaznik zakaznik) 
	{
		//Ucet u= zakaznik.getUcet();
		SporiaciUcet u= zakaznik.getSporiaciUcet();
		double uZostatok= u.getZostatok();
		double pridanaSuma= uZostatok* urokovaMiera/100;
		double zurocenyZostatok= uZostatok + pridanaSuma;
		u.zostatok= zurocenyZostatok;
		System.out.println("Urokova suma: " + pridanaSuma + ", zostatok po zuroceni: "+ u.getZostatok());
		
	}
	
	public Zakaznik najdiZakaznika(int hladaneId) {
		for(int i=0; i< zakaznici.size(); i++) {
			Zakaznik akt= zakaznici.get(i);
			if(akt.getId() == hladaneId) {
				System.out.println("zakaznik" + akt.getMeno() +" najdeny, pozicia" + i);
				return akt;
			}
		}
		//System.out.println("zakaznik nenajdeny");
		return null;
	}
	
	public void novyZakaznik(String nMeno, Ucet nUcet, int nId, int nVek) {
		if(najdiZakaznika(nId) == null) {
			zakaznici.add(new Zakaznik(nMeno, nUcet, nId, nVek));
			pocetZakaznikov= pocetZakaznikov+1;
			System.out.println("Zakaznik pridany");
		} else {
			System.out.println("Zakaznik tu uz je");
		}
	}
	
	public void novyZvyhodneny(String nMeno, Ucet nUcet, int nId, int nVek, String nTyp) {
		if(najdiZakaznika(nId) == null) {
			zakaznici.add(new Zvyhodneny(nMeno, nUcet, nId, nVek, nTyp));
			pocetZakaznikov= pocetZakaznikov+1;
			System.out.println("Zakaznik pridany");
		} else {
			System.out.println("Zakaznik tu uz je");
		}
	}
	
	public Banka() {
		this.pocetZakaznikov= 0;
		this.zakaznici = new ArrayList<Zakaznik>();
	}
	
	public ArrayList<Zakaznik> getZakaznici() {
		return zakaznici;
	}
	
	public int getPocetZakaznikov()
	{
		return pocetZakaznikov;
	}	
	public double getUrokovaMiera()
	{
		return urokovaMiera;
	}
	
	public double getPoplatok() 
	{
		return poplatok;
	}

}
