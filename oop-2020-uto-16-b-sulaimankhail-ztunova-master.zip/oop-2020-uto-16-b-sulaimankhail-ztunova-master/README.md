# oop-2020-uto-16-b-sulaimankhail-ztunova
oop-2020-uto-16-b-sulaimankhail-ztunova created by GitHub Classroom

Ovladanie programu:
pri spusteni sa zobrazi registracny formular. Prostrednictvom neho je mozne do banky pridat zakaznikov. Suma na ucte musi byt aspon 50. Po zaregistrovani je mozne sa prihlasit kliknutim na "Prihlasit sa". Zakaznik banky sa prihlasuje svojim menom a ako heslo sa pouziva zakaznikovo ID. Po prihlaseni sa zobrazi uvodna obrazovka bankoveho systemu. Na nej je vidno informacie o ucte a historia vykonanych platieb a vkladov. Z tejto uvodnej obrazovky je mozne sa tlacitkami preklikavat medzi vykonanim platby alebo vkladu alebo kontrolou svojho sporiaceho uctu. Ten ja treba najskor zalozit. Potom sa budu zobrazovat informacie o sporiacom ucte s moznostou prevodu z bezneho uctu na sporiaci. Kliknutim na "Odhlasit" sa vratite na registraciu noveho zakaznika. Zakaznika ktory uz je raz zaregistrovany netreba registrovat viackrat, staci sa prihlasit.
.............................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................

V projekte sa venujem vytvoreniu bankového systému.
Mám vytvorenú abstraktnú triedu Zakaznik, z ktorého dedia ďaľšie triedy. 
Konkrétne z neho dedí trieda Manzelia, Jednotlivec a ďaľšia abstraktná tridrieda SVyhodami, ktorá obsahuje určité zvýhodnené paramtre
pre niektoré triedy, ako napríklad výhodnejší poplatok za vedenie účtu alebo výhodnejší úrok.
Z triedy SVyhodami dedia triedy Student, Senior a Zamestnanec.
Hierarchia dedenia teda vyzerá takto: Zakaznik---> Manzelia, Jednotlivec, SVyhodami---> Student, Senior, Zamestnanec.
Ďaľšia abstraktná trieda je trieda Ucet. Z nej dedi trieda BeznyUcet a SporiaciUcet (Ucet--->BeznyUcet, SporiaciUcet).

Agregácia je použitá v triedach zákazníkov. Abstraktná trieda Zakaznik obsahuje triedu BeznyUcet => každému zákazníkovi je pridelený 
bežný účet. Trieda jednotlivec obsahuje navyše aj triedu SporiaciUcet a triedy Manzelia a Zamestnanci obsahujú triedu UverovyUcet.

Trieda banka obsahuje len funkciu main, v ktorej vytváram jednotlivé objekty a robia sa v nej kontrolné výpisy.
