package banka;

import java.io.IOException;

import GUI.Registracia;
import GUI.Uvod;

public class Main {
	public static void main(String[] args) throws NumberFormatException, IOException
	{
		Banka banka= new Banka(8.5, 10);
		Registracia reg= new Registracia(banka);
		reg.zobrazRegistraciu();
		
		/*BankaApp banka= new BankaApp(8.5, 20);
		banka.zobrazMenu();
		*/
	}

}
