package projektOOP;

public class BeznyUcet extends Ucet {
	
	double poplatok;
	boolean trvalyPrikaz;
	double trvalyPSuma;
	String trvalyPObdobie;
	
	public void setBeznyUcet(boolean TP, double tpSuma, String obdobie) {
		this.trvalyPrikaz= TP;
		this.trvalyPSuma= tpSuma;
		this.trvalyPObdobie= obdobie;
	}
	
	public boolean getTP() {
		return trvalyPrikaz;
	}
	
	public double getTpSuma() {
		return trvalyPSuma;
	}
	
}
