package projektOOP;

public class Student extends SVyhodami {
	boolean brigada;
	
	public void setBrigada(boolean pracuje) {
		this.brigada= pracuje;
	}
}
