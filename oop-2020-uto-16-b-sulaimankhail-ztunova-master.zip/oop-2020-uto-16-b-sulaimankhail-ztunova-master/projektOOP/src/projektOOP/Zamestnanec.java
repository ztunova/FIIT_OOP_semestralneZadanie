package projektOOP;

public class Zamestnanec extends SVyhodami {
	int odpracovaneRoky;
	double inyMajetok;
	UverovyUcet uverovyUcet;
	
	public void setOdpracovane(int roky) {
		this.odpracovaneRoky= roky;
	}
	
	public int getOdpracovane() {
		return odpracovaneRoky;
	}
	
	public void setMajetok(double majetok) {
		this.inyMajetok= majetok;
	}
	
	public double getMajetok() {
		return inyMajetok;
	}
	
	public void setUver(UverovyUcet novyUver) {
		this.uverovyUcet= novyUver;
	}
	
	public UverovyUcet getUver()
	{
		return this.uverovyUcet;
	}
}
