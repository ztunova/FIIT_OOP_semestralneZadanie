package projektOOP;

abstract class Zakaznik {
	private int vek;
	private double prijem;
	BeznyUcet beznyUcet;
	
	public void setUcet(BeznyUcet ucet) {
		this.beznyUcet= ucet;
	}
	
	public BeznyUcet getUcet() {
		return beznyUcet;
	}
		
	public void setVek(int roky) {
		this.vek= roky;
	}
	
	public int getVek() {
		return vek;
	}
	
	public void setPrijem(double suma) {
		this.prijem= suma;
	}
	
	public double getPrijem() {
		return prijem;
	}
	
}
