package projektOOP;

public class Senior extends SVyhodami {
	double dochodok;
	double inyMajetok;
	
	public void setMajetok(double majetok) {
		this.inyMajetok= majetok;
	}
	
	public double getMajetok() {
		return inyMajetok;
	}
	
	public void setDochodok(double suma) {
		this.dochodok= suma;
	}
	
	public double getDochodok() {
		return dochodok;
	}
}
