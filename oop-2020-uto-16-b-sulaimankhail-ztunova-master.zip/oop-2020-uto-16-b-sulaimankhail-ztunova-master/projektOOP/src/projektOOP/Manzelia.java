package projektOOP;

public class Manzelia extends Zakaznik {
	int pocetDeti;
	double inyMajetok;
	boolean zamestnanie;
	UverovyUcet uverovyUcet;
	
	public void setDeti(int pocet) {
		this.pocetDeti= pocet;
	}
	
	public void setMajetok(double majetok) {
		this.inyMajetok= majetok;
	}
	
	public double getMajetok() {
		return inyMajetok;
	}
	
	public void setZamestnanie(boolean praca) {
		this.zamestnanie= praca;
	}
	
	public boolean getZamestanie() {
		return zamestnanie;
	}
	
	public void setUver(UverovyUcet novyUver) {
		this.uverovyUcet= novyUver;
	}
	
	public UverovyUcet getUver()
	{
		return this.uverovyUcet;
	}
	

}
