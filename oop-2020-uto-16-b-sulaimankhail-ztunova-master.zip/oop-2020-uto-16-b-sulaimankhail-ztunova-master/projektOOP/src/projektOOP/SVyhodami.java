package projektOOP;

abstract class SVyhodami extends Zakaznik{
	private double vyhodnejsiPoplatok;
	private double vyhodnejsiUrok;
	
	public void setPoplatok(double novyPopl) {
		this.vyhodnejsiPoplatok= novyPopl;
	}
	
	public double getPoplatok() {
		return vyhodnejsiPoplatok;
	}
	
	public void setUrok(double novyUrok) {
		this.vyhodnejsiUrok= novyUrok;
	}
	
	public double getUrok() {
		return vyhodnejsiUrok;
	}

}
