package projektOOP;
//import java.util.Scanner;

public class banka {
	
	public static void main(String[] args) 
	{
	
		SporiaciUcet ucet1= new SporiaciUcet();
		BeznyUcet ucet2= new BeznyUcet();
		UverovyUcet ucet3= new UverovyUcet();
		BeznyUcet ucet4= new BeznyUcet();
		
		ucet1.setZostatok(789);
		ucet1.setSporiacaSuma(20.2);
		
		ucet2.setZostatok(900);
		ucet2.setBeznyUcet(true, 10.5, "rok");
		
		ucet3.setPozicka(70000);
		ucet4.setZostatok(1500);
		ucet4.setBeznyUcet(false, 0, null);
		ucet4.poplatok= 7.5;
		
		Jednotlivec jednotlivec= new Jednotlivec();
		jednotlivec.setVek(50);
		jednotlivec.setPrijem(500);
		jednotlivec.sporiaciUcet= ucet1;
		
		Student student= new Student();
		student.setBrigada(false);
		student.setUcet(ucet2);
		
		Manzelia manzelia= new Manzelia();
		manzelia.setDeti(2);
		manzelia.setUver(ucet3);
		manzelia.setUcet(ucet4);
		
		System.out.println("jednotlivec: vek " + jednotlivec.getVek() + ", prijem " + jednotlivec.getPrijem());
		System.out.println("sporiaca suma: " + jednotlivec.getSporenie().getSporiacaSuma());
		
		System.out.println("student: zostatok na ucte:" + student.getUcet().getZostatok());
		System.out.println("ucet: TP: " + student.getUcet().getTP() + " pravidelna platba: "+student.getUcet().getTpSuma());
		
		System.out.println("manzelia: uver: " + manzelia.getUver().getPozicane() + " zostatok na beznom ucte: " +manzelia.getUcet().getZostatok());
		System.out.println("bezny ucet: TP: " + manzelia.getUcet().getTP() + " pravidelna platba: "+ manzelia.getUcet().getTpSuma());
	}
		
		

}
