package projektOOP;

public class UverovyUcet {
	double pozicanaSuma;
	double zostavajuciDlh;
	
	public void setPozicka(double pozicane) {
		this.pozicanaSuma = pozicane;
	}
	
	public double getPozicane() {
		return this.pozicanaSuma;
	}

}
