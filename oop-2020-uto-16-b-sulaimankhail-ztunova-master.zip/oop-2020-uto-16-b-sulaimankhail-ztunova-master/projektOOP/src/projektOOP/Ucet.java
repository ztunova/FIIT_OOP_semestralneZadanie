package projektOOP;

class Ucet {
	double zostatok;
	
	public void setZostatok(double suma) {
		this.zostatok= suma;
	}
	
	public double getZostatok() {
		return zostatok;
	}
}
