package projektOOP;

public class SporiaciUcet extends Ucet {
	double sporiacaSuma;
	double urok;
	
/*	public SporiaciUcet(double suma)
	{
		this.sporiacaSuma = suma;
	}*/
	
	public void setSporiacaSuma(double suma) {
		this.sporiacaSuma= suma;
	}
	
	public void setUrok(double novyUrok) {
		this.urok= novyUrok;
	}
	
	public double getSporiacaSuma()
	{
		return this.sporiacaSuma;
	}

}
