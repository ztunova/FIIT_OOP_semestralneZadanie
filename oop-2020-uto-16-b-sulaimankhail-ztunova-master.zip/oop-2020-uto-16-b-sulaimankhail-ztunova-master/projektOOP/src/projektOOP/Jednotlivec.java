package projektOOP;

public class Jednotlivec extends Zakaznik {
	double inyMajetok;
	boolean zamestnanie;
	SporiaciUcet sporiaciUcet;
	
	public void setMajetok(double majetok) {
		this.inyMajetok= majetok;
	}
	
	public double getMajetok() {
		return inyMajetok;
	}
	
	public void setZamestnanie(boolean zamestnany) {
		this.zamestnanie= zamestnany;
	}
	
	public boolean getZamestnanie() {
		return zamestnanie;
	}
	
	public void setSporenie(SporiaciUcet noveSporenie) {
		this.sporiaciUcet= noveSporenie;
	}
	
	public SporiaciUcet getSporenie()
	{
		return this.sporiaciUcet;
	}
	
/*	void vytvorSporenie(double sporenie)
	{
		SporiaciUcet S= new SporiaciUcet();
		Jednotlivec A= new Jednotlivec();
		A.setSporenie(S);
		A.getSporenie().setSporiacaSuma(sporenie);
		System.out.println(A.getSporenie().getSporiacaSuma());	
	}*/

}
